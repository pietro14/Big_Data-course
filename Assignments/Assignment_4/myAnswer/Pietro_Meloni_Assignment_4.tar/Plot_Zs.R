## This is an R scirpt written by Pietro Meloni
## and it must be executed from the CODE directory.
## The only argument of the script is a file name
## (without the path)


args=commandArgs(trailingOnly=TRUE) 

	data <- read.table(file = paste0("../OUTPUT/", args[1]), sep="\t", header = T)

	jpeg(		file = paste0("../OUTPUT/Zplot_", args[1], ".jpeg"),
			width=1000,
			height=1000,
			units = c("px"),
			res = 100
	    )


	plot(   	x = abs(data$Z1),
			y = abs(data$Z2),
			main = "Pietro's Z-plot",
			xlab = "Z_beta_se",
			ylab = "Z_pval",
			col = "blue",
#			pch = 1
	    )




dev.off()



