#!/bin/bash

# This script must be executed in the CODE directory 
# where you can find add_Zs.R and Plot_Zs.R as well
file=$1

if [ $# -eq 0 ]
then
echo "Error: No file name has been supplied."
exit 1
elif [ $# -gt 1 ]
then
echo "Error: You have supplied more than one file names. Please specify only one." 
exit 1
else
echo "The script is being executed" 
fi

function remove_dups {
	sort -u -k1,1 ../INPUT/$1  > ../INPUT/Nodups_$1
}
echo "Removing duplicates..."
remove_dups $file


echo "Adding Z columns..."
Rscript --no-save add_Zs.R Nodups_$file
echo "Plotting..."
Rscript --no-save Plot_Zs.R Z1_Z2_Nodups_$file


echo "Cleaning final file..."
awk 'function abs(x){return ((x < 0.0) ? -x : x)}\
NR==1{print $0, "Z_outlier"}\
NR>1{if(abs($10/$11)>1.1 || abs($11/$10)>1.1){\
print $0, "1"}\
else{\
print $0, "0"}}' \
OFS='\t' ../OUTPUT/Z1_Z2_Nodups_$file | awk -F"\t" \
'NR==1{print}NR>1{if($12!=1){print}}' OFS="\t"  > ../OUTPUT/Cleaned_$file  

echo "Plotting..."
Rscript --no-save Plot_Zs.R Cleaned_$file

## END OF SCRIPT ##


