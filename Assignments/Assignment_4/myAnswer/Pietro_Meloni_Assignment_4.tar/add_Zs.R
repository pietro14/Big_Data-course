##   This is a R script written by Pietro Meloni,   
##   and it must be executed from the CODE directory
##   The only argument of the script is a file name
##   (without the path)


args=commandArgs(trailingOnly=TRUE) 

	my_df <- read.table(file = paste0("../INPUT/", args[1]), sep="\t", header = T)

	my_df$Z1 <- my_df$Beta/my_df$SE	
	my_df$Z2 <- qnorm(1 - my_df$Pval/2)	

	write.table(my_df, file=paste0("../OUTPUT/Z1_Z2_",args[1]), sep="\t", row.names=F ,col.names=T, quote=F)

